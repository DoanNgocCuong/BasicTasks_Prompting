# Strategy: Adaptive x Personalized x Pika character

**Bài SCALE UP và TĂNG QUALITY**

**Roadmap lớn:** 

Trình độ: A2 ⇒ expand

Roadmap A2: 

**Objective/Goal về engagement đã chốt.**