# Engagement Roadmap - Personalized

Tôi muốn thiết kế Pika freetalk hàng ngày với trẻ, như một người bạn chia sẻ mọi thông tin và kể, update cho nhau mọi thứ mà trẻ quan tâm trong cuộc sống.
Để làm tốt phần này, tôi cần phân loại các dạng thông tin mà 1 đứa trẻ có thể hay nói về, theo mức độ hứng thú từ thấp tới cao, hoặc phân loại theo bất cứ cách nào khác.

ví dụ như mọi thông tin về những người thân và mối quan hệ của trẻ.
các sự kiện không xảy ra thường xuyên nhưng trẻ hứng thú như sắp được đi du lịch, được bố mẹ dẫn đi ăn gà rán món ăn yêu thích, sắp đến Tết và về quê, sắp được nghỉ hè, sắp thi...

Hãy nghĩ thêm các cách tiếp cận phân loại khác.

Hệ thống:

- Topic, sub-topics
- Thông tin tĩnh, thông tin động

Ai gửi lại giúp mình phần Personalization + Adaptive Learning phía học thuật (components breakdowns như htr trao đổi) đc ko, để mình gói lại research dần về AI technique

[**Mức độ Pika nên nắm bắt và lồng ghép thông tin cá nhân hóa vào hội thoại**](Engagement%20Roadmap%20-%20Personalized%201ab1adf5293f8175a190f149c150bcd6/Mu%CC%9B%CC%81c%20%C4%91o%CC%A3%CC%82%20Pika%20ne%CC%82n%20na%CC%86%CC%81m%20ba%CC%86%CC%81t%20va%CC%80%20lo%CC%82%CC%80ng%20ghe%CC%81p%20%201ab1adf5293f810e9156e0b865c56467.md)

## **Tóm tắt thiết kế Personalized & Adaptive cho Pika**

| **Yếu tố** | **Cá nhân hóa (Personalized)** | **Thích ứng (Adaptive)** |
| --- | --- | --- |
| Hồ sơ người học | Đánh giá trình độ đầu vào | Điều chỉnh bài học dựa trên trình độ đầu vào.
Theo thời gian, sẽ điều chỉnh khó hơn theo |
| Chủ đề hội thoại | Pika nói về những chủ đề bé thích (game, động vật, v.v.).  | Chủ đề có thể mở rộng theo mức độ bé tiến bộ. |
| Theo dõi tiến trình | Ghi nhớ lỗi sai, từ vựng cần ôn tập. | Đưa từ vựng/cấu trúc hay quên vào hội thoại hằng ngày, hoặc hoạt động học space repetition. |
| Cách phản hồi positive reinforcement |  | Nếu bé gặp khó, Pika đưa gợi ý từng bước một. |
| Gắn kết cảm xúc | Hỏi thăm về chuyện cá nhân của bé, nhớ các câu chuyện trước đó. | Phản hồi cảm xúc phù hợp khi bé vui, buồn, hoặc chán học. |

Nói về các nội dung trẻ quan tâm ⇒ Tạo thành các bài học ⇒ 1 Function Learning Loop

1 Function Learning Loop ⇒ Lỗi sai vào dạy kỹ hơn bằng SR

Talk: user-focus, luôn lấy nội dung của trẻ làm trọng tâm, và có phản hồi đúng intent

Các nội dung dạy tiếng Anh được trích xuất từ Talk 

Đánh giá trình độ đầu vào của trẻ và đưa ra learning loop phù hợp.

Trong quá trình học learning loop, phản hồi positive reinforcement theo năng lực trả lời của trẻ.

Trích xuất ra các từ trẻ hay sai ⇒ đẩy vào ôn tập ngắt quãng - learning loop mở rộng.