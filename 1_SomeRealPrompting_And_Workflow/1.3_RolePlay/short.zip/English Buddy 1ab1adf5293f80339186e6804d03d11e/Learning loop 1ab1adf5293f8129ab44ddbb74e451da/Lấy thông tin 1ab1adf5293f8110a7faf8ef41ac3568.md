# Lấy thông tin

## Hỏi tên, tuổi, lớp mấy, có anh chị em không, bố mẹ làm nghề gì…

## Các chủ đề gợi ý để “khai thác” sở thích của trẻ

1. **Chủ đề hằng ngày**
    - “Con thích làm gì sau giờ học?”
    - “Con thích đi chơi ở đâu vào cuối tuần?”
    - “Món ăn con thích nhất là gì?”
2. **Chủ đề học tập, trường lớp**
    - “Trong lớp con thích môn học nào nhất?”
    - “Con có tham gia câu lạc bộ hay hoạt động nào ở trường không?”
    - “Con thích gì ở thầy cô hoặc bạn bè?”
3. **Chủ đề giải trí, sáng tạo**
    - “Con có thích xem phim/hoạt hình/YouTube không? Thể loại nào?”
    - “Con hay đọc sách/truyện gì? Nhân vật nào làm con ấn tượng?”
    - “Nếu con được làm siêu anh hùng, con muốn có siêu năng lực gì?”
4. **Sở thích cá nhân**
    - “Con có chơi nhạc cụ không? Nếu có, con thích loại nhạc nào?”
    - “Con có thích vẽ, tô màu hay làm đồ thủ công không?”
    - “Con thích thể thao hay trò chơi nào? (bóng đá, cầu lông, đá banh điện tử, board game…)”
5. **Chủ đề ước mơ, tương lai** (đặc biệt với nhóm 8–12 tuổi)
    - “Khi lớn lên con muốn làm nghề gì?”
    - “Con muốn được đi đâu hoặc khám phá nơi nào?”

### **Kịch bản phân nhánh sau khi trẻ nói sở thích:**

- Nếu trẻ nói thích vẽ, chatbot gợi ý vài câu hỏi tiếp theo liên quan đến vẽ (màu sắc, nhân vật tranh, gần đây có vẽ không vẽ gì…).
- Nếu trẻ nói thích thể thao, chatbot đi sâu hơn vào loại hình thể thao, thần tượng vận động viên…