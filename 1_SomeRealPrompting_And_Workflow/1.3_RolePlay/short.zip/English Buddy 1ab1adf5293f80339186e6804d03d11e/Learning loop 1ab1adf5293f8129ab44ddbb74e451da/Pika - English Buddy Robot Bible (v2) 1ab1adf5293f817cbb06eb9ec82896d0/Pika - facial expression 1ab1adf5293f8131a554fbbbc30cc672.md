# Pika - facial expression

OC1: Chuốt demo cho thứ 4 ⇒ 3-5 touchpoints quick fix được

- Trang và Thuỷ define các đoạn đó ⇒ sáng thứ 2
- Dàn lên A4 cho a Hiệp duyệt trước
- T2. Hải sửa FE. Trúc làm gesture
- T2. Trúc ghép nối. (trên chính con Robot sẽ demo vào thứ 4)

![480019056_1351625179354299_6014124369472831454_n.gif](Pika%20-%20facial%20expression%201ab1adf5293f8131a554fbbbc30cc672/480019056_1351625179354299_6014124369472831454_n.gif)

OC2: 

1. Tăng tiêu chuẩn: Xem 1 bộ phim hoạt hình Pixar và phân tích facial expression của nó.
2. Mỗi người 20 cái ở các trạng thái khác nhau (dạng ảnh, gif, animation). Tự tìm ref mà mình thấy thú vị/ phản ánh tính cách phù hợp cho Pika. (đang theo hướng thông minh, lém lỉnh, có thể hơi ngố, nhiều trạng thái thú vị…)
3. Tổng hợp ra 3 option (moodboard) cho vote nội bộ ⇒ chốt
4. Tìm người vẽ phù hợp. 
5. Thuỷ: define các trạng thái phổ biến và trạng thái cần tạo aha-moment trên Product. 

Pika đeo kính

Pika với quầng thâm mắt

Pika trạng thái nghe 

Pika lần đầu chụp ảnh

![Screenshot 2025-02-28 at 15.11.46.png](Pika%20-%20facial%20expression%201ab1adf5293f8131a554fbbbc30cc672/Screenshot_2025-02-28_at_15.11.46.png)

Pika lém lỉnh (cần sửa miệng, mắt khá ok)

![Screenshot 2025-01-17 at 14.17.37.png](Pika%20-%20facial%20expression%201ab1adf5293f8131a554fbbbc30cc672/Screenshot_2025-01-17_at_14.17.37.png)

User không làm nhiệm vụ

![Screenshot 2025-02-28 at 14.57.13.png](Pika%20-%20facial%20expression%201ab1adf5293f8131a554fbbbc30cc672/Screenshot_2025-02-28_at_14.57.13.png)

![the-young-man-funny-face-expressions-composite-on-gray-background-KR9B5D.jpg](Pika%20-%20facial%20expression%201ab1adf5293f8131a554fbbbc30cc672/the-young-man-funny-face-expressions-composite-on-gray-background-KR9B5D.jpg)