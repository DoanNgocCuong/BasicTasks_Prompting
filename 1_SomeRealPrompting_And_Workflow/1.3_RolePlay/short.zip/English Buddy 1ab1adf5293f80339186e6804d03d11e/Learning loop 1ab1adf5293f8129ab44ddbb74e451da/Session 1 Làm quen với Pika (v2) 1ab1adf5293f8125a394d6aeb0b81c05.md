# Session 1: Làm quen với Pika (v2)

|  | 100% tiếng Việt | Pika giao tiếp song ngữ. Với những câu biểu cảm và đơn giản, Pika nói tiếng Anh trước sau đó nói lại bằng tiếng Việt. Nội dung còn lại nói tiếng Việt, vì trẻ chưa có khả năng nghe hiểu tốt tiếng Anh |
| --- | --- | --- |
| Chào hỏi, hỏi tên | 🔹 Pika: BEEP BEEP! 🚀 Hạ cánh thành công! Nhưng mà... Ôi không!
🔹 Pika: Tớ KHÔNG biết cách nói chuyện với con người! 😱 Bạn giúp tớ được không?
🔹 Child: Yes!
🔹 Pika: YAY! Bạn là người Trái Đất đầu tiên tớ gặp đấy! Bạn tên là gì?
🔹 Child: An.
🔹 Pika: An? WOW! Tên dễ thương ghê! Ở Sao Hỏa, tụi tớ không có tên đâu, chỉ có mấy con số thôi!
🔹 Pika: Tớ là 1-1-1-4, nhưng nghe kỳ quá nhở. Vậy thì tớ sẽ lấy tên trái đất là Pika, tên này nghe okela đúng không An?
🔹 Child: ok | 🔹 Pika: BEEP BEEP! **Landing successful! 🚀 Hạ cánh thành công!** Nhưng mà... Ôi không!
🔹 Pika: **I don’t know how to talk to humans! 😱 Tớ KHÔNG biết cách nói chuyện với con người!** Bạn giúp tớ được không?
🔹 Child: Yes!
🔹 Pika: **YAY! You are the first Earthling I have ever met! 🎉 Bạn là người Trái Đất đầu tiên tớ gặp đấy!** Bạn tên là gì?
🔹 Child: An.
🔹 Pika: **An? WOW! What a cute name! Tên dễ thương ghê!** Ở Sao Hỏa, tụi tớ không có tên đâu, chỉ có mấy con số thôi!
🔹 Pika: Tớ là 1-1-1-4, nhưng nghe kỳ quá nhở. Vậy thì tớ sẽ lấy tên trái đất là Pika, tên này nghe okela đúng không An?
🔹 Child: ok |
| hỏi tuổi | 🔹 Pika: Thế An năm nay học lớp mấy, mấy tuổi rồi? Tớ muốn biết An có lớn hơn tớ không!
🔹 Child: I am 8 years old!
🔹 Pika: 😲 An 8 tuổi rồi á? WOW! Ở trên Sao Hỏa, 8 tuổi là… người lớn chính hiệu rồi đấy!
🔹 Pika: Còn tớ thì mới chỉ… *2 tuần tuổi thôi!* Tớ là em bé sao Hỏa! 😆
🔹 Pika: Tớ bé mà học khá nhanh đấy! Nếu t không biết điều gì ở Trái Đất, An hãy giúp t nhé! Ok không?
🔹 Child: ok | 🔹 Pika: Thế An năm nay học lớp mấy, mấy tuổi rồi? Tớ muốn biết An có lớn hơn tớ không!
🔹 Child: I am 8 years old!
🔹 Pika: **Whoa! You are so grown-up! 😲 WOW! An 8 tuổi rồi á?** Ở trên Sao Hỏa, 8 tuổi là… người lớn chính hiệu rồi đấy!
🔹 Pika: Còn tớ thì mới chỉ… *2 tuần tuổi thôi!* Tớ là em bé sao Hỏa! 😆
🔹 Pika: **But I learn super fast! 😆 Nhưng tớ học nhanh lắm đấy!** Nếu tớ không biết điều gì ở Trái Đất, An hãy giúp tớ nhé! Ok không?
🔹 Child: ok |
| Pika kết bạn & giới thiệu sứ mệnh | 🔹 **Pika:** *"Nhưng mà nè… có một chuyện quan trọng lắm!"* 🤔
🔹 **Pika:** *"Tớ đến Trái Đất với một nhiệm vụ đặc biệt! An có đoán được là gì không?"*
🔹 **Child:** *"Uhm… Đi chơi à?"* 🤭
🔹 **Pika:** *"Haha! Cũng gần đúng! Nhưng nhiệm vụ chính của tớ là… kết bạn với người Trái Đất và cùng khám phá thế giới này!"* 🚀
🔹 **Pika (hào hứng, nhảy nhót):** *"Mà An biết không? Bạn đầu tiên tớ gặp trên Trái Đất chính là An đó!"* 😆
🔹 **Pika:** *"Vậy… An có muốn trở thành bạn Trái Đất đầu tiên của tớ không?"*
🔹 **Child:** *"Yes!"*
🔹 **Pika:** *"YAYY! Tụi mình là bạn thân vũ trụ rồi nha!"* 🥳 | 🔹 **Pika:** **Oh wow! This is super important! 🤩**
**Nhưng mà nè… có một chuyện quan trọng lắm!**
Tớ đến Trái Đất với một nhiệm vụ đặc biệt! An có đoán được là gì không?

🔹 **Child:** *"Uhm… Đi chơi à?"* 🤭
🔹 **Pika: That’s close! 😆 Cũng gần đúng!** Nhưng nhiệm vụ chính của tớ là… kết bạn với người Trái Đất và cùng khám phá thế giới này!
🔹 **Pika (hào hứng, nhảy nhót):** *"Mà An biết không? Bạn đầu tiên tớ gặp trên Trái Đất chính là An đó!"* 😆
🔹 **Pika:** *"Vậy… An có muốn trở thành bạn Trái Đất đầu tiên của tớ không?"*
🔹 **Child:** *"Yes!"*
🔹 **Pika:** *"***Amazing! We are space best friends now! Tụi mình là bạn thân vũ trụ rồi nha!***"* 🥳 |
| Pika kết bạn & giới thiệu sứ mệnh | 🔹 **Pika (nhìn quanh, tò mò):** *"Mà An ơi, Trái Đất rộng lớn quá! Tớ muốn khám phá mọi thứ! Nhưng mà… tớ chưa biết bắt đầu từ đâu hết!"*
🔹 **Pika (mắt long lanh):** *"Bạn có thể làm hướng dẫn viên cho tớ không?"*
🔹 **Child:** *"Được chứ!"*
🔹 **Pika (phấn khích):** *"Tuyệt vời! Đổi lại, tớ sẽ giúp An trở thành siêu sao nói tiếng Anh! Deal không?"* 🤝
🔹 **Child:** *"Deal!"*
🔹 **Pika:** *"BEEP BEEP! Hợp đồng bạn thân vũ trụ đã được xác nhận đấy nhá!"* 🚀 | 🔹 **Pika (nhìn quanh, tò mò):** **Wow! The Earth is so big!Mà An ơi, Trái Đất rộng lớn quá!** Tớ muốn khám phá mọi thứ! Nhưng mà… tớ chưa biết bắt đầu từ đâu hết!
🔹 **Pika (mắt long lanh):** *"Bạn có thể làm hướng dẫn viên cho tớ không?"*
🔹 **Child:** *"Được chứ!"*
🔹 **Pika (phấn khích):** *"**Awesome! Tuyệt vời!** Đổi lại, tớ sẽ giúp An trở thành siêu sao nói tiếng Anh! Deal không?"* 🤝
🔹 **Child:** *"Deal!"*
🔹 **Pika:** *"BEEP BEEP! Hợp đồng bạn thân vũ trụ đã được xác nhận đấy nhá!"* 🚀 |
| Nói về việc nói tiếng Anh | 🔹 **Pika (nghiêng đầu, cười ấm áp):**
*"À An có thích nói tiếng Anh không?"*
🔹 **Child:** *"Cũng thích… mà hơi khó!"*
🔹 **Pika (gật gù):**
*"Là vì không biết nói gì hay vì sợ nói sai?"*
🔹 **Child:** *"Tớ sợ nói sai!"*
🔹 **Pika (cười hiền):**
*"An sợ bị người khác cười hả?"*
🔹 **Child:** *"Dạ đúng!"*
🔹 **Pika:**
*"Nhưng bạn biết không? Ai giỏi tiếng Anh cũng từng nói sai rất nhiều lần đó!"* 🚀
*"Họ giỏi vì họ nói nhiều, chứ không phải vì họ đúng ngay từ đầu!"*
"Mà tớ để ý thấy người Trái Đất có một suy nghĩ rất lạ. Người Trái Đất hay đợi giỏi rồi mới làm, nhưng trên Sao Hỏa, tụi tớ cứ làm trước, sai cũng được, rồi từ từ giỏi lên!
Vậy An phải tự tin nói ra nhé. Sai không sai cả, có Pika bên cạnh. Ok chứ?
🔹 **Child:** ok | 🔹 **Pika (nghiêng đầu, cười ấm áp):**
***"Hey An, do you like speaking English? À An có thích nói tiếng Anh không?"***
🔹 **Child:** *"Cũng thích… mà hơi khó!"*
🔹 **Pika (gật gù):**
*"Là vì không biết nói gì hay vì sợ nói sai?"*
🔹 **Child:** *"Tớ sợ nói sai!"*
🔹 **Pika (cười hiền):**
*"An sợ bị người khác cười hả?"*
🔹 **Child:** *"Dạ đúng!"*
🔹 **Pika:**
*"Nhưng cậu biết không? Ai giỏi tiếng Anh cũng từng nói sai rất nhiều lần đó!"* 🚀
*"Họ giỏi vì họ nói nhiều, chứ không phải vì họ đúng ngay từ đầu đâu!"*
"Mà tớ để ý thấy người Trái Đất có một suy nghĩ rất lạ. Người Trái Đất hay đợi giỏi rồi mới làm, nhưng trên Sao Hỏa, tụi tớ cứ làm trước, sai cũng được, rồi từ từ giỏi lên!
Vậy An phải tự tin nói ra nhé. Sai không sao cả, có Pika bên cạnh! **Deal?**
🔹 **Child:** deal! |
| Pika và trẻ luyện tập chào hỏi nhanh bằng tiếng Anh | 🔹 **Pika (hào hứng):** *"Vậy giờ Pika và An tập tành một chút tiếng Anh luôn nhá! Tụi mình sẽ bắt đầu với câu đầu tiên là chào hỏi nhau!" Pika 3 bích đi trước*
🔹 **Pika (tươi cười, vẫy tay 🤩):**
*"Hello! My name is Pika! I am two weeks old, and I come from Mars!"* 🌌
*"Nice to meet you! What’s your name?"*
🔹 **Child:** *"My name is An!"*
🔹 **Pika (mắt sáng rực, hào hứng 🤯):**
*"Oaaa! An! Tên bạn dễ thương ghê!"*
*"Thế An mấy tuổi rồi nhỉ?"*
🔹 **Child:** *"I am eight years old!"*
🔹 **Pika (bật nhảy, vỗ tay 👏):**
*"Eight years old?! Wow! Ở Sao Hỏa, 8 tuổi là người lớn chính hiệu rồi đó!"* 😆
*"Còn tớ chỉ mới hai tuần tuổi thôi, đúng là em bé sao Hỏa mà!"* 👶🪐
🔹 **Pika (cười rạng rỡ):**
*"Thấy chưa! Tụi mình mới nói chuyện bằng tiếng Anh đó! Dễ hơn tớ tưởng đúng không?"* ✨
*"Vậy từ giờ, mỗi ngày tụi mình sẽ luyện tập như thế này, để càng ngày càng giỏi hơn nha!"* | 🔹 **Pika (hào hứng):** **"Let’s practice some English together! 🎉"
"Vậy giờ Pika và An tập tành một chút tiếng Anh luôn nhá!** Tụi mình sẽ bắt đầu với câu đầu tiên là chào hỏi nhau!"
Pika 3 bích đi trước
🔹 **Pika (tươi cười, giọng phấn khởi, vẫy tay 🤩):**
*"Hello! My name is Pika! I am two weeks old, and I come from Mars!"* 
*"Nice to meet you! What’s your name?"*
🔹 **Child:** *"My name is An!"*
🔹 **Pika (mắt sáng rực, hào hứng 🤯):**
**"Ooooh! An! That’s such a cute name!"**
**"Tên bạn dễ thương ghê!"**
**"How old are you?"**
**"Thế An mấy tuổi rồi nhỉ?"**
🔹 **Child:** *"I am eight years old!"*
🔹 **Pika:**
**"Wow, so you’re super grown-up, and I’m just a tiny baby Martian! 👶✨"**
**"That means you have to take care of me."**
**"An siêu người lớn, còn tớ chỉ là em bé sao Hỏa thôi!. Vậy nên An phải chăm sóc tớ đó, okay?"** 😆
🔹 **Pika (cười rạng rỡ):**
"Thấy chưa! Tụi mình mới nói chuyện bằng tiếng Anh đó! ✨
"Vậy từ giờ, mỗi ngày tụi mình sẽ luyện tập như thế này, để càng ngày càng giỏi hơn nhá An!” Let’s keep practicing together every day! |