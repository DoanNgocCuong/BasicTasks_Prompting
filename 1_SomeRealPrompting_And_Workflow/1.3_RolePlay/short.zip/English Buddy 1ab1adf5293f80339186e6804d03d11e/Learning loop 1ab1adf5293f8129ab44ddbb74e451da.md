# Learning loop

**Goal prioritization:**

1. Engagement
2. Nghe và nói tiếng Anh tự tin hơn và nhiều dần
3. Hiệu quả

---

[Pika - **English Buddy Robot**  (v1)](Learning%20loop%201ab1adf5293f8129ab44ddbb74e451da/Pika%20-%20English%20Buddy%20Robot%20(v1)%201ab1adf5293f81e382b6d9f7c36c329b.md)

[Session 1: Làm quen với Pika & thu thập thông tin cá nhân của trẻ (v1)](Learning%20loop%201ab1adf5293f8129ab44ddbb74e451da/Session%201%20La%CC%80m%20quen%20vo%CC%9B%CC%81i%20Pika%20&%20thu%20tha%CC%A3%CC%82p%20tho%CC%82ng%201ab1adf5293f81f9b300d8ef649f9da8.md)

**Pika learning loop. Dual:** https://docs.google.com/document/d/1sbV51zbfwFJlnv8kwviVURqwHvueA8jh4xYIzHGsL0k/edit?tab=t.0#heading=h.4aeprkivvvwh

[Session 1: Làm quen với Pika (v2)](Learning%20loop%201ab1adf5293f8129ab44ddbb74e451da/Session%201%20La%CC%80m%20quen%20vo%CC%9B%CC%81i%20Pika%20(v2)%201ab1adf5293f8125a394d6aeb0b81c05.md)

[Strategy: Adaptive x Personalized x Pika character](Learning%20loop%201ab1adf5293f8129ab44ddbb74e451da/Strategy%20Adaptive%20x%20Personalized%20x%20Pika%20character%201ab1adf5293f8111bae0e33ec8e07a3e.md)

[Pika - **English Buddy Robot Bible (v2)**          ](Learning%20loop%201ab1adf5293f8129ab44ddbb74e451da/Pika%20-%20English%20Buddy%20Robot%20Bible%20(v2)%201ab1adf5293f817cbb06eb9ec82896d0.md)

[Engagement Roadmap - Personalized](Learning%20loop%201ab1adf5293f8129ab44ddbb74e451da/Engagement%20Roadmap%20-%20Personalized%201ab1adf5293f8175a190f149c150bcd6.md)

[Lấy thông tin](Learning%20loop%201ab1adf5293f8129ab44ddbb74e451da/La%CC%82%CC%81y%20tho%CC%82ng%20tin%201ab1adf5293f8110a7faf8ef41ac3568.md)

[Talks- the first 2 weeks - Uncovering What Kids Love!](Learning%20loop%201ab1adf5293f8129ab44ddbb74e451da/Talks-%20the%20first%202%20weeks%20-%20Uncovering%20What%20Kids%20Lo%201ab1adf5293f81569a1ed117346d66bc.md)