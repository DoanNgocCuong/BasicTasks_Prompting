# Decision-making criteria

![Screenshot 2025-02-12 at 17.06.16.png](Decision-making%20criteria%201ab1adf5293f81aab9c2c17ca7005905/Screenshot_2025-02-12_at_17.06.16.png)